import Sidebar from './components/Sidebar';
import TopBar from './components/TopBar';
import PageHeader from './components/PageHeader';
import InteractionHistory from './components/InteractionHistory';
import TasksSchedule from './components/TasksSchedule';
import StageFunnel from './components/StageFunnel';
import CustomerProfile from './components/CustomerProfile';
import DetailedInfo from './components/DetailedInfo';

export default function App() {
  return (
    <div
      className="min-h-screen flex items-center justify-center p-6"
      style={{ background: '#B9BBC2' }}
    >
      {/* Main panel */}
      <div
        className="relative w-full overflow-hidden"
        style={{
          maxWidth: '1380px',
          borderRadius: '22px',
          background: 'linear-gradient(135deg, #EAF1F6 0%, #EEF4EC 50%, #F4F6EF 100%)',
          boxShadow: '0 32px 120px rgba(0,0,0,0.18)',
          minHeight: '90vh',
        }}
      >
        {/* Background blobs */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none" style={{ zIndex: 0 }}>
          <div
            style={{
              position: 'absolute',
              top: '15%',
              left: '-8%',
              width: '420px',
              height: '420px',
              background: 'radial-gradient(circle, rgba(39,92,232,0.13), transparent 65%)',
              filter: 'blur(60px)',
            }}
          />
          <div
            style={{
              position: 'absolute',
              top: '20%',
              right: '-5%',
              width: '380px',
              height: '380px',
              background: 'radial-gradient(circle, rgba(76,200,140,0.12), transparent 65%)',
              filter: 'blur(60px)',
            }}
          />
          <div
            style={{
              position: 'absolute',
              bottom: '10%',
              left: '35%',
              width: '320px',
              height: '320px',
              background: 'radial-gradient(circle, rgba(236,234,60,0.10), transparent 65%)',
              filter: 'blur(55px)',
            }}
          />
          <div
            style={{
              position: 'absolute',
              top: '30%',
              right: '8%',
              width: '280px',
              height: '280px',
              background: 'radial-gradient(circle, rgba(255,92,180,0.16), transparent 60%)',
              filter: 'blur(50px)',
            }}
          />
          <div
            style={{
              position: 'absolute',
              bottom: '25%',
              right: '20%',
              width: '260px',
              height: '260px',
              background: 'radial-gradient(circle, rgba(76,156,173,0.12), transparent 60%)',
              filter: 'blur(48px)',
            }}
          />
        </div>

        {/* Content */}
        <div className="relative" style={{ zIndex: 10 }}>
          <TopBar />

          <div className="flex gap-4 px-4 pb-5">
            <Sidebar />

            <div className="flex-1 min-w-0 flex flex-col gap-4">
              <PageHeader />

              <div className="flex gap-4">
                {/* Main content */}
                <div className="flex-1 min-w-0 flex flex-col gap-4">
                  <InteractionHistory />

                  <div className="flex gap-4">
                    <TasksSchedule />
                    <StageFunnel />
                  </div>
                </div>

                {/* Right column */}
                <div className="flex flex-col gap-4" style={{ width: '260px', flexShrink: 0 }}>
                  <CustomerProfile />
                  <DetailedInfo />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
