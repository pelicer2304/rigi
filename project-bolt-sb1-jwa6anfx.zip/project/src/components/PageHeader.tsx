import { ChevronLeft, BarChart2, Users, CheckSquare } from 'lucide-react';

export default function PageHeader() {
  return (
    <div className="flex items-center gap-8 px-6 py-4">
      {/* Back + Title */}
      <div className="flex items-center gap-4 flex-shrink-0">
        <button
          className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 transition-all duration-200"
          style={{
            background: 'rgba(255,255,255,0.5)',
            border: '1px solid rgba(255,255,255,0.6)',
          }}
        >
          <ChevronLeft size={15} style={{ color: '#6B7280' }} />
        </button>
        <h1 className="text-3xl font-bold leading-tight" style={{ color: '#111827' }}>
          Customer<br />Information
        </h1>
      </div>

      {/* Metrics */}
      <div className="flex items-center gap-6 flex-1">
        {/* Revenue */}
        <div className="flex items-center gap-3">
          <div
            className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: 'rgba(255,255,255,0.45)', border: '1px solid rgba(255,255,255,0.6)' }}
          >
            <BarChart2 size={16} style={{ color: '#6B7280' }} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-base font-bold" style={{ color: '#111827' }}>$1,980,130</span>
              <span
                className="text-xs font-semibold px-2 py-0.5 rounded-full"
                style={{ background: '#ECEA3C', color: '#111827' }}
              >
                +11% week
              </span>
            </div>
            <div className="text-xs" style={{ color: '#6B7280' }}>
              Won from 76 Deals<br />This Month
            </div>
          </div>
        </div>

        {/* New Customers */}
        <div className="flex items-center gap-3">
          <div
            className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: 'rgba(255,255,255,0.45)', border: '1px solid rgba(255,255,255,0.6)' }}
          >
            <Users size={16} style={{ color: '#6B7280' }} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-base font-bold" style={{ color: '#111827' }}>+89</span>
              <span
                className="text-xs font-semibold px-2 py-0.5 rounded-full"
                style={{ background: '#275CE8', color: '#fff' }}
              >
                +12 today
              </span>
            </div>
            <div className="text-xs" style={{ color: '#6B7280' }}>
              New Customers<br />for Week
            </div>
          </div>
        </div>

        {/* New Tasks */}
        <div className="flex items-center gap-3">
          <div
            className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: 'rgba(255,255,255,0.45)', border: '1px solid rgba(255,255,255,0.6)' }}
          >
            <CheckSquare size={16} style={{ color: '#6B7280' }} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-base font-bold" style={{ color: '#111827' }}>+31</span>
              <span
                className="text-xs font-semibold px-2 py-0.5 rounded-full"
                style={{ background: 'rgba(255,255,255,0.7)', color: '#374151', border: '1px solid rgba(0,0,0,0.08)' }}
              >
                +5 today
              </span>
            </div>
            <div className="text-xs" style={{ color: '#6B7280' }}>
              New Tasks<br />for Week
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
