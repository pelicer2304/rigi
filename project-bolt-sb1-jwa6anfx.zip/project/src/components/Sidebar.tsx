import { Search, Share2, Upload, Star, Plus, Smartphone, BookOpen, Calendar, Navigation, BarChart2 } from 'lucide-react';

const icons = [Search, Share2, Upload, Star, Plus, Smartphone, BookOpen, Calendar, Navigation, BarChart2];

export default function Sidebar() {
  return (
    <div
      className="flex flex-col items-center py-4 gap-3 rounded-[28px] w-12 flex-shrink-0"
      style={{
        background: 'rgba(10, 18, 10, 0.82)',
        backdropFilter: 'blur(20px)',
        WebkitBackdropFilter: 'blur(20px)',
        border: '1px solid rgba(255,255,255,0.08)',
        boxShadow: '0 8px 32px rgba(0,0,0,0.18)',
      }}
    >
      {icons.map((Icon, i) => (
        <button
          key={i}
          className="w-8 h-8 flex items-center justify-center rounded-xl transition-all duration-200"
          style={{
            background: i === 0 ? 'rgba(255,255,255,0.14)' : 'transparent',
            color: i === 0 ? '#fff' : 'rgba(255,255,255,0.45)',
          }}
          onMouseEnter={e => {
            if (i !== 0) (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.08)';
          }}
          onMouseLeave={e => {
            if (i !== 0) (e.currentTarget as HTMLElement).style.background = 'transparent';
          }}
        >
          <Icon size={15} />
        </button>
      ))}
    </div>
  );
}
