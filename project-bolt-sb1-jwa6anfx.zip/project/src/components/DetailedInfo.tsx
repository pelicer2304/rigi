import { User, Mail, Phone, Link2, Calendar, Pencil, Plus, ArrowUpRight } from 'lucide-react';

interface InfoRowProps {
  icon: React.ReactNode;
  label: string;
  value: React.ReactNode;
  action?: React.ReactNode;
}

function InfoRow({ icon, label, value, action }: InfoRowProps) {
  return (
    <div className="flex items-center gap-3 py-2.5">
      <div
        className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0"
        style={{ background: 'rgba(255,255,255,0.5)', border: '1px solid rgba(255,255,255,0.7)' }}
      >
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-[10px] font-medium mb-0.5" style={{ color: '#9CA3AF' }}>{label}</div>
        <div className="text-xs font-semibold truncate" style={{ color: '#111827' }}>{value}</div>
      </div>
      {action && (
        <div className="flex-shrink-0">{action}</div>
      )}
    </div>
  );
}

function SmallBtn({ children }: { children: React.ReactNode }) {
  return (
    <button
      className="w-6 h-6 rounded-full flex items-center justify-center"
      style={{ background: 'rgba(255,255,255,0.5)', border: '1px solid rgba(255,255,255,0.7)' }}
    >
      {children}
    </button>
  );
}

const sourceIcons = [
  { color: '#25D366', label: 'WhatsApp', char: 'W' },
  { color: '#4A154B', label: 'Slack', char: 'S' },
  { color: '#0077B5', label: 'LinkedIn', char: 'in' },
  { color: '#5865F2', label: 'Discord', char: 'D' },
];

export default function DetailedInfo() {
  return (
    <div
      className="relative rounded-[28px] p-5 overflow-hidden"
      style={{
        background: 'rgba(255,255,255,0.28)',
        backdropFilter: 'blur(22px)',
        WebkitBackdropFilter: 'blur(22px)',
        border: '1px solid rgba(255,255,255,0.5)',
        boxShadow: '0 20px 60px rgba(31,41,55,0.08)',
      }}
    >
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-sm font-semibold" style={{ color: '#111827' }}>Detailed Information</h2>
        <div className="flex gap-1.5">
          <SmallBtn><Pencil size={11} style={{ color: '#9CA3AF' }} /></SmallBtn>
          <SmallBtn><ArrowUpRight size={11} style={{ color: '#9CA3AF' }} /></SmallBtn>
        </div>
      </div>

      <div
        className="divide-y"
        style={{ borderColor: 'rgba(0,0,0,0.04)' }}
      >
        <InfoRow
          icon={<User size={12} style={{ color: '#9CA3AF' }} />}
          label="First Name"
          value="Eva"
          action={<SmallBtn><Pencil size={11} style={{ color: '#9CA3AF' }} /></SmallBtn>}
        />
        <InfoRow
          icon={<User size={12} style={{ color: '#9CA3AF' }} />}
          label="Last Name"
          value="Robinson"
          action={<SmallBtn><Pencil size={11} style={{ color: '#9CA3AF' }} /></SmallBtn>}
        />
        <InfoRow
          icon={<Mail size={12} style={{ color: '#9CA3AF' }} />}
          label="Email"
          value="Eva@alabamamachinery.com"
          action={<SmallBtn><Plus size={11} style={{ color: '#9CA3AF' }} /></SmallBtn>}
        />
        <InfoRow
          icon={<Phone size={12} style={{ color: '#9CA3AF' }} />}
          label="Phone Number"
          value="+91 120 222 313"
          action={<SmallBtn><Plus size={11} style={{ color: '#9CA3AF' }} /></SmallBtn>}
        />
        <InfoRow
          icon={<Link2 size={12} style={{ color: '#9CA3AF' }} />}
          label="Sources"
          value={
            <div className="flex gap-1.5 mt-0.5">
              {sourceIcons.map(s => (
                <span
                  key={s.label}
                  className="w-5 h-5 rounded-full flex items-center justify-center text-white text-[9px] font-bold"
                  style={{ background: s.color }}
                  title={s.label}
                >
                  {s.char}
                </span>
              ))}
            </div>
          }
          action={<SmallBtn><Link2 size={11} style={{ color: '#9CA3AF' }} /></SmallBtn>}
        />
        <InfoRow
          icon={<Calendar size={12} style={{ color: '#9CA3AF' }} />}
          label="Last Contacted"
          value="06/15/2023 at 7:16 pm"
          action={<SmallBtn><ArrowUpRight size={11} style={{ color: '#9CA3AF' }} /></SmallBtn>}
        />
      </div>
    </div>
  );
}
