import { MoreHorizontal, ArrowUpRight } from 'lucide-react';

const avatars = [
  'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=40&h=40&fit=crop',
  'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=40&h=40&fit=crop',
  'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=40&h=40&fit=crop',
];

interface DealCardProps {
  date: string;
  name: string;
  subtitle: string;
  amount: string;
  variant: 'blue' | 'teal' | 'black' | 'yellow' | 'white';
}

function DealCard({ date, name, subtitle, amount, variant }: DealCardProps) {
  const styles: Record<string, React.CSSProperties> = {
    blue: {
      background: 'rgba(39, 84, 232, 0.88)',
      backdropFilter: 'blur(18px)',
      WebkitBackdropFilter: 'blur(18px)',
      border: '1px solid rgba(100,140,255,0.35)',
      color: '#fff',
    },
    teal: {
      background: 'rgba(76, 156, 173, 0.88)',
      backdropFilter: 'blur(18px)',
      WebkitBackdropFilter: 'blur(18px)',
      border: '1px solid rgba(120,200,220,0.35)',
      color: '#fff',
    },
    black: {
      background: 'rgba(5, 5, 5, 0.90)',
      backdropFilter: 'blur(18px)',
      WebkitBackdropFilter: 'blur(18px)',
      border: '1px solid rgba(255,255,255,0.12)',
      color: '#fff',
    },
    yellow: {
      background: 'rgba(236, 234, 60, 0.92)',
      backdropFilter: 'blur(18px)',
      WebkitBackdropFilter: 'blur(18px)',
      border: '1px solid rgba(255,255,160,0.4)',
      color: '#111827',
    },
    white: {
      background: 'rgba(255,255,255,0.28)',
      backdropFilter: 'blur(22px)',
      WebkitBackdropFilter: 'blur(22px)',
      border: '1px solid rgba(255,255,255,0.55)',
      color: '#111827',
      boxShadow: '0 8px 32px rgba(31,41,55,0.06)',
    },
  };

  const isLight = variant === 'yellow' || variant === 'white';

  return (
    <div
      className="relative rounded-[22px] p-4 flex flex-col justify-between h-36 transition-transform duration-200 hover:scale-[1.02] cursor-pointer overflow-hidden"
      style={styles[variant]}
    >
      <div className="flex items-start justify-between">
        <div>
          <div className="text-xs font-medium mb-1 opacity-70">{date}</div>
          <div className="text-sm font-semibold leading-tight">{name}</div>
          <div className="text-xs opacity-60 mt-0.5">{subtitle}</div>
        </div>
        <button
          className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0"
          style={{
            background: isLight ? 'rgba(0,0,0,0.08)' : 'rgba(255,255,255,0.15)',
          }}
        >
          {variant === 'black' ? (
            <ArrowUpRight size={13} style={{ color: '#fff' }} />
          ) : (
            <MoreHorizontal size={13} style={{ color: isLight ? '#374151' : '#fff' }} />
          )}
        </button>
      </div>

      <div className="flex items-end justify-between">
        <span className="text-lg font-bold">{amount}</span>
        <div className="flex -space-x-2">
          {avatars.map((src, i) => (
            <img
              key={i}
              src={src}
              alt=""
              className="w-6 h-6 rounded-full object-cover"
              style={{ border: `2px solid ${isLight ? 'rgba(255,255,255,0.8)' : 'rgba(0,0,0,0.3)'}` }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

export default function InteractionHistory() {
  return (
    <div
      className="relative rounded-[28px] p-5 overflow-hidden"
      style={{
        background: 'rgba(255,255,255,0.28)',
        backdropFilter: 'blur(22px)',
        WebkitBackdropFilter: 'blur(22px)',
        border: '1px solid rgba(255,255,255,0.45)',
        boxShadow: '0 20px 60px rgba(31,41,55,0.08)',
      }}
    >
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-sm font-semibold" style={{ color: '#111827' }}>Interaction History</h2>
        <div className="flex gap-1.5">
          <button
            className="w-7 h-7 rounded-full flex items-center justify-center"
            style={{ background: 'rgba(255,255,255,0.5)', border: '1px solid rgba(255,255,255,0.7)' }}
          >
            <MoreHorizontal size={13} style={{ color: '#9CA3AF' }} />
          </button>
          <button
            className="w-7 h-7 rounded-full flex items-center justify-center"
            style={{ background: 'rgba(255,255,255,0.5)', border: '1px solid rgba(255,255,255,0.7)' }}
          >
            <ArrowUpRight size={13} style={{ color: '#9CA3AF' }} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <DealCard date="Oct 4" name="Royal Package" subtitle="Opportunity" amount="11,250$" variant="blue" />
        <DealCard date="Oct 16" name="Third Deal," subtitle="Most Useful" amount="21,300$" variant="teal" />
        <DealCard date="Oct 12" name="Absolute" subtitle="Success Deal" amount="2,100$" variant="black" />
        <DealCard date="Oct 11" name="Royal Package" subtitle="Opportunity" amount="4,160$" variant="yellow" />
        <DealCard date="Oct 2" name="Adaptive" subtitle="Business Services" amount="3,140$" variant="white" />
        <DealCard date="Oct 2" name="Second Deal," subtitle="Common Service" amount="12,350$" variant="white" />
      </div>
    </div>
  );
}
