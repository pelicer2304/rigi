import { MoreHorizontal, ArrowUpRight, Pencil, Mail, Phone, Plus, Calendar, FileText } from 'lucide-react';

const actionIcons = [
  { Icon: Pencil, label: 'Edit' },
  { Icon: Mail, label: 'Email' },
  { Icon: Phone, label: 'Call' },
  { Icon: Plus, label: 'Add' },
  { Icon: Calendar, label: 'Schedule' },
  { Icon: FileText, label: 'File' },
];

export default function CustomerProfile() {
  return (
    <div
      className="relative rounded-[28px] p-5 overflow-hidden"
      style={{
        background: 'rgba(255,255,255,0.28)',
        backdropFilter: 'blur(22px)',
        WebkitBackdropFilter: 'blur(22px)',
        border: '1px solid rgba(255,255,255,0.5)',
        boxShadow: '0 20px 60px rgba(31,41,55,0.08)',
      }}
    >
      {/* Decorative glows */}
      <div
        className="absolute pointer-events-none"
        style={{
          top: '10%',
          left: '50%',
          transform: 'translateX(-50%)',
          width: '220px',
          height: '220px',
          background: 'radial-gradient(circle, rgba(255, 92, 180, 0.38), transparent 60%)',
          filter: 'blur(40px)',
          zIndex: 0,
        }}
      />
      <div
        className="absolute pointer-events-none"
        style={{
          bottom: '-20px',
          right: '-20px',
          width: '200px',
          height: '200px',
          background: 'radial-gradient(circle, rgba(169, 255, 195, 0.32), transparent 65%)',
          filter: 'blur(50px)',
          zIndex: 0,
        }}
      />
      <div
        className="absolute pointer-events-none"
        style={{
          top: '50%',
          left: '-30px',
          width: '140px',
          height: '140px',
          background: 'radial-gradient(circle, rgba(39,92,232,0.12), transparent 65%)',
          filter: 'blur(35px)',
          zIndex: 0,
        }}
      />

      {/* Content */}
      <div className="relative z-10">
        {/* Top controls */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex gap-1.5">
            <button
              className="w-7 h-7 rounded-full flex items-center justify-center"
              style={{ background: 'rgba(255,255,255,0.55)', border: '1px solid rgba(255,255,255,0.7)' }}
            >
              <ArrowUpRight size={13} style={{ color: '#9CA3AF', transform: 'rotate(180deg) scaleX(-1)' }} />
            </button>
            <button
              className="w-7 h-7 rounded-full flex items-center justify-center"
              style={{ background: 'rgba(255,255,255,0.55)', border: '1px solid rgba(255,255,255,0.7)' }}
            >
              <ArrowUpRight size={13} style={{ color: '#9CA3AF' }} />
            </button>
          </div>
          <div className="flex gap-1.5">
            <button
              className="w-7 h-7 rounded-full flex items-center justify-center"
              style={{ background: 'rgba(255,255,255,0.55)', border: '1px solid rgba(255,255,255,0.7)' }}
            >
              <MoreHorizontal size={13} style={{ color: '#9CA3AF' }} />
            </button>
            <button
              className="w-7 h-7 rounded-full flex items-center justify-center"
              style={{ background: 'rgba(255,255,255,0.55)', border: '1px solid rgba(255,255,255,0.7)' }}
            >
              <ArrowUpRight size={13} style={{ color: '#9CA3AF' }} />
            </button>
          </div>
        </div>

        {/* Avatar */}
        <div className="flex flex-col items-center mb-4">
          <div className="relative mb-3">
            <div
              className="absolute inset-0 rounded-full"
              style={{
                background: 'radial-gradient(circle, rgba(255,92,180,0.45) 0%, transparent 70%)',
                filter: 'blur(16px)',
                transform: 'scale(1.3)',
              }}
            />
            <img
              src="https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop"
              alt="Eva Robinson"
              className="relative w-20 h-20 rounded-full object-cover"
              style={{
                border: '3px solid rgba(255,255,255,0.8)',
                boxShadow: '0 8px 32px rgba(255,92,180,0.25)',
              }}
            />
          </div>
          <h3 className="text-base font-bold mb-0.5" style={{ color: '#111827' }}>Eva Robinson</h3>
          <p className="text-xs text-center" style={{ color: '#9CA3AF', maxWidth: '140px' }}>
            CEO, Inc. Alabama Machinery & Supply
          </p>
        </div>

        {/* Action icons */}
        <div className="flex items-center justify-center gap-2">
          {actionIcons.map(({ Icon, label }) => (
            <button
              key={label}
              title={label}
              className="w-8 h-8 rounded-full flex items-center justify-center transition-all duration-200"
              style={{
                background: 'rgba(255,255,255,0.55)',
                border: '1px solid rgba(255,255,255,0.7)',
              }}
              onMouseEnter={e => {
                (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.8)';
              }}
              onMouseLeave={e => {
                (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.55)';
              }}
            >
              <Icon size={13} style={{ color: '#6B7280' }} />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
